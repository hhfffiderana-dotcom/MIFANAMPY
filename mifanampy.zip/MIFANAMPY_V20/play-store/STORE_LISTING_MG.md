# MIFANAMPY – Fampahafantarana Google Play (drafitra)

## Anaran'ny application
MIFANAMPY

## Famaritana fohy
Fifampizarana • Fampianarana • Fanampiana

## Famaritana lava
MIFANAMPY dia sehatra natao hanamorana ny fifampizarana fahalalana sy ny fianarana. Afaka mijery ireo fiofanana misy ny mpampiasa, manaraka ny votoaty, ary mifandray amin'ny mpampiofana araka ny fahafahan'ny sehatra.

Ny mpampiofana dia afaka manolotra fiofanana hodinihin'ny mpitantana. Misy ihany koa ny sehatra fitantanana kaonty sy ny fizotry ny fangatahana fandoavam-bola.

**Tanjona:** Mifampizara izay hainao. Mianara izay ilainao. Mifanampy amin'ny zavatra mahasoa.

## Sokajy atolotra
Education (hamarinina amin'ny tena votoaty sy ny safidin'ny Google Play).

## Fanamarihana alohan'ny famoahana
- Hamarino sy fenoy ny mailaka sy tranonkala ofisialy hifandraisana.
- Aza mampiditra filazana momba ny taratasy fanamarinana satria tsy manome certificat ny MIFANAMPY.
- Hamarino amin'ny kinova farany ny endri-javatra tena mandeha alohan'ny hampiasana ity famaritana ity.
- Ampio sary screenshot tena nalaina tao amin'ny app, fa tsy mockup mamitaka.


Fanavaozana V20: nohatsaraina ny pejy fandraisana sy ny fitantanana mombamomba ny mpampiasa.
