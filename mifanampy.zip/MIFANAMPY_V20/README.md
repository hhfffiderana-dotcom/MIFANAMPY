# MIFANAMPY V20 – Fanatsarana ny pejy fandraisana sy ny kaonty

## Zavatra nohatsaraina
- Nalamina ho fizarana mazava ny pejy fandraisana: Fifandraisana, Fampianarana, fitaovan'ny Formateur/Admin ary Kaonty.
- Nohatsaraina ny fanehoana ny teny fandraisana sy ny tanjon'ny MIFANAMPY.
- Nampiana pejy mombamomba ahafahan'ny mpampiasa manavao ny anarany sy ny laharana finday.
- Nampiana fangatahana rohy fanovana mot de passe amin'ny alalan'ny Firebase Authentication.
- Nohavaozina ho versionCode 20 / versionName 20.0.

## Fanamarihana ara-teknika
- Ity dia source project Android Studio, fa tsy APK/AAB.
- Tsy mbola natao Gradle build na fitsapana amin'ny fitaovana Android.
- Mila Firestore Rules mamela ny tompon-kaonty hanavao ny saha `name` sy `phone` ao amin'ny `users/{uid}` ihany. Tsy tokony hahafahany manova ny saha `role`.
- Ny fiarovana ny fandoavam-bola, ny fanamarinana Quiz ary ny fanapahan-kevitra momba ny vola dia mbola mila backend/Cloud Functions sy fitsapana fiarovana alohan'ny tena hampiasana azy.

## Fanokafana
Sokafy amin'ny Android Studio ny lahatahiry fototry ny tetikasa. Hamarino ny Firebase configuration sy ny Firestore/Storage Rules alohan'ny hanaovana build.
