# Lisitra fanomanana Google Play – MIFANAMPY V19

## Kaody sy fanamboarana
- [ ] Build sy test amin'ny Android Studio amin'ny solosaina.
- [ ] Hamarino ny Firebase configuration sy ny Firestore/Storage Rules.
- [ ] Hamarino amin'ny kaonty Student, Formateur ary Admin.
- [ ] Hamarino ny famafana kaonty sy angona raha misy kaonty azo foronina ao amin'ny app.
- [ ] Hamarino fa voaaro amin'ny backend ny scoring quiz sy ny fankatoavana/fizarana vola.
- [ ] Mamoròna Android App Bundle (.aab) voasonia; aza mizara keystore na ny tenimiafiny.

## Pejy Google Play
- [ ] Anarana, famaritana fohy sy lava.
- [ ] Sary famantarana sy sary screenshot tena avy amin'ny app.
- [ ] URL politika momba ny tsiambaratelo HTTPS.
- [ ] Data safety form mifanaraka amin'ny angona sy SDK tena ampiasaina.
- [ ] App access instructions ho an'ny mpandinika raha misy fidirana mila kaonty.
- [ ] Content rating sy target audience marina.
- [ ] Fepetra momba ny kaonty sy famafana kaonty.

## Fandoavam-bola
- [ ] Farito mazava raha fandoavana ivelan'ny app na fividianana nomerika ao anatin'ny app.
- [ ] Diniho ny politikan'ny Google Play Billing alohan'ny famoahana.
- [ ] Aza mampiasa vola tena izy raha tsy voamarina amin'ny backend ny porofo, ny 25%/75%, ny saldo ary ny retrait.

## Zava-dehibe
Ity V19 ity dia manomana antontan-taratasy sy metadata. Tsy midika fa efa neken'ny Google Play ny app, ary tsy APK na AAB vonona hapetraka.
