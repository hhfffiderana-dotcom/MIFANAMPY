# Politika momba ny tsiambaratelo – MIFANAMPY (DRAFITRA)

**Daty fanavaozana:** [fenoy]

Ity antontan-taratasy ity dia drafitra mila dinihina sy fenoin'ny tompon'ny MIFANAMPY alohan'ny hamoahana azy ampahibemaso. Tsy mbola politika farany ara-dalàna.

## 1. Angona mety hokarakaraina
Araka ny endri-javatra ampidirina ao amin'ny application, mety hokarakaraina ny:
- mombamomba ny kaonty sy ny mombamomba ny mpampiasa;
- votoaty sy rakitra alefan'ny mpampiofana;
- hafatra sy fifandraisana ao anatin'ny app;
- fandrosoana sy valin'ny quiz;
- fangatahana fandoavam-bola sy antontan-taratasy fanamarinana raha alefa ao amin'ny app.

**Tsy maintsy hamarinina** ny angona tena angonin'ny kinova farany sy ny SDK rehetra tafiditra ao anatiny. Aza avela ao amin'ity politika ity izay angona tsy angonin'ny app.

## 2. Antony ampiasana azy
Ampiasaina hanomezana sy hitantanana ny kaonty, hanehoana fiofanana, hitahirizana ny fandrosoana, hanamorana ny fifandraisana, ary hitantanana ny fangatahana mifandraika amin'ny serivisy.

## 3. Mpamatsy tolotra
Ny tetikasa dia mampiasa Firebase Authentication, Cloud Firestore ary Firebase Storage. Hamarino ao amin'ny Firebase Console sy ny kaody farany ny serivisy tena ampiasaina sy ny toerana itehirizana angona.

## 4. Fizarana angona
Farito eto raha misy mpampiofana, mpitantana, mpanome tolotra na antoko fahatelo mahazo angona, ary inona marina no anton'izany. Aza milaza fa tsy misy fizarana raha mbola tsy voamarina.

## 5. Fiarovana sy fitahirizana
Ampiasao ny fitsipika fiarovana mifanaraka amin'ny andraikitry ny mpampiasa. Farito ny fe-potoana fitahirizana sy ny fomba famafana angona. Tsy misy rafitra afaka miantoka fiarovana tanteraka.

## 6. Zo sy fangatahan'ny mpampiasa
Ampidiro eto ny fomba fangatahana hijerena, hanitsiana na hamafana ny angon-drakitra, ary ny fomba famafana kaonty raha misy.

## 7. Ankizy
Farito mazava raha natao ho an'ny ankizy ilay app, ny taona farany ambany, ary ny fepetra takiana. Aza mamoaka raha tsy voafaritra sy voahaja ireo fepetra ireo.

## 8. Fifandraisana
Tompon'andraikitra: HERIMAMONJY HARITIANA FANAMBINANTSOA FIDERANA
Mailaka: [ampidiro mailaka ofisialy]
Adiresin'ny pejy politika: [ampidiro URL ampahibemaso HTTPS]

---

**Aza alefa ao amin'ny Google Play ity drafitra ity raha mbola misy [fenoy] na raha tsy mbola mifanaraka amin'ny fomba fiasan'ny app.**
