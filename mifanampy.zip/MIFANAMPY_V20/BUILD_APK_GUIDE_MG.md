# Torolalana hananganana APK – MIFANAMPY V20

## Fanomanana
1. Sokafy amin'ny Android Studio ny lahatahiry fototry ny tetikasa `MIFANAMPY_V20`.
2. Avelao ny Android Studio hanao Gradle Sync ary hametraka ireo Android SDK ilaina (compileSdk 35).
3. Hamarino fa ny `app/google-services.json` dia an'ny Firebase project `mifanampy-7357e` ary mifanaraka amin'ny package `mg.mifanampy.app`.
4. Andramo aloha ny `Build > Make Project` ary ahitsio izay lesoka asehon'ny Android Studio.

## APK fitsapana
- Safidio `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
- Rehefa vita soa aman-tsara, tsindrio `locate` ao amin'ny fampandrenesana Android Studio.
- Ny APK debug dia matetika ao amin'ny `app/build/outputs/apk/debug/app-debug.apk`.

## APK famoahana
Aza mizara APK release raha tsy efa voasedra. Ampiasao `Build > Generate Signed Bundle / APK` ary tehirizo soa aman-tsara ny signing key.

## Zava-dehibe
Ity tetikasa ity mbola tsy voa-build na voasedra amin'ny Android SDK eto. Ny fanamarinana ZIP dia tsy midika fa efa mandeha ny application. Andramo amin'ny Android Studio sy fitaovana Android aloha, ary aza mampiasa paiement tena izy raha tsy voasedra sy voaaro amin'ny backend ny fanamarinana paiement sy ny kajy vola.
