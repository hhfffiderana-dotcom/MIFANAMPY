package mg.mifanampy.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import com.google.firebase.auth.*;
import com.google.firebase.firestore.*;
import com.google.firebase.storage.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root; FirebaseAuth auth; FirebaseFirestore db; FirebaseStorage storage;
    final int BLUE=Color.rgb(24,86,160), GREEN=Color.rgb(32,132,94), ORANGE=Color.rgb(232,139,48), LIGHT=Color.rgb(243,247,252), INK=Color.rgb(35,49,66), MUTED=Color.rgb(103,118,136);
    String currentRole="student"; Uri selectedVideo, selectedPdf;

    @Override public void onCreate(Bundle b){ super.onCreate(b); auth=FirebaseAuth.getInstance(); db=FirebaseFirestore.getInstance(); storage=FirebaseStorage.getInstance();
        if(auth.getCurrentUser()!=null) loadRoleAndHome(); else login(); }

    GradientDrawable shape(int color,int radius,int strokeColor){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(strokeColor!=Color.TRANSPARENT)d.setStroke(1,strokeColor);return d;}
    TextView title(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(25);t.setTextColor(BLUE);t.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));t.setPadding(4,20,4,12);return t;}
    TextView text(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(15);t.setTextColor(INK);t.setLineSpacing(3,1.05f);t.setPadding(12,10,12,12);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setTextColor(Color.WHITE);b.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));b.setAllCaps(false);b.setPadding(18,10,18,10);b.setBackground(shape(BLUE,24,Color.TRANSPARENT));if(Build.VERSION.SDK_INT>=21)b.setElevation(2);return b;}
    EditText input(String h,boolean password){EditText e=new EditText(this);e.setHint(h);e.setTextSize(15);e.setSingleLine(!h.toLowerCase().contains("description")&&!h.toLowerCase().contains("hafatra"));e.setTextColor(INK);e.setHintTextColor(MUTED);e.setPadding(16,12,16,12);e.setBackground(shape(Color.rgb(248,250,253),16,Color.rgb(222,230,239)));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return e;}
    void base(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(18,10,18,26);root.setBackgroundColor(LIGHT);ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(root);setContentView(sv);if(Build.VERSION.SDK_INT>=21){getWindow().setStatusBarColor(BLUE);getWindow().setNavigationBarColor(Color.rgb(18,61,112));}}
    Button action(String s,View.OnClickListener l){Button b=btn(s);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,5,0,7);b.setLayoutParams(lp);b.setOnClickListener(l);return b;}
    void login(){base();root.addView(title("MIFANAMPY"));root.addView(text("Fifampizarana • Fampianarana • Fanampiana"));EditText email=input("Email",false),pass=input("Mot de passe",true);root.addView(email);root.addView(pass);Button b=btn("Hiditra");root.addView(b);Button r=btn("Mamorona compte vaovao");root.addView(r);
        b.setOnClickListener(v->auth.signInWithEmailAndPassword(email.getText().toString().trim(),pass.getText().toString()).addOnSuccessListener(x->loadRoleAndHome()).addOnFailureListener(e->toast("Email na mot de passe tsy marina.")));
        r.setOnClickListener(v->register()); }
    void register(){base();root.addView(title("Mamorona compte"));EditText name=input("Anarana feno",false),phone=input("Téléphone",false),email=input("Email",false),pass=input("Mot de passe (6 caractères farafahakeliny)",true);root.addView(name);root.addView(phone);root.addView(email);root.addView(pass);
        Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Mpianatra / Mpampiasa","Formateur"}));root.addView(sp);Button b=btn("Hisoratra anarana");root.addView(b);root.addView(action("← Hiverina",v->login()));
        b.setOnClickListener(v->{String n=name.getText().toString().trim(),p=phone.getText().toString().trim(),em=email.getText().toString().trim(),pw=pass.getText().toString();if(n.isEmpty()||em.isEmpty()||pw.length()<6){toast("Fenoy tsara ny anarana, email ary mot de passe (6 farafahakeliny).");return;}String role=sp.getSelectedItemPosition()==1?"formateur":"student";
            auth.createUserWithEmailAndPassword(em,pw).addOnSuccessListener(x->{Map<String,Object> m=new HashMap<>();m.put("name",n);m.put("phone",p);m.put("email",em);m.put("role",role);m.put("createdAt",FieldValue.serverTimestamp());db.collection("users").document(x.getUser().getUid()).set(m).addOnSuccessListener(z->loadRoleAndHome()).addOnFailureListener(e->toast("Tsy voatahiry ny profil."));}).addOnFailureListener(e->toast("Tsy nety ny inscription: "+e.getMessage()));}); }
    void loadRoleAndHome(){if(auth.getCurrentUser()==null){login();return;}db.collection("users").document(auth.getCurrentUser().getUid()).get().addOnSuccessListener(d->{currentRole=d.exists()&&d.getString("role")!=null?d.getString("role"):"student";home();}).addOnFailureListener(e->home());}
    void home(){
        base();
        TextView brand=title("MIFANAMPY");brand.setTextSize(30);brand.setPadding(4,18,4,4);root.addView(brand);
        TextView tagline=text("Fifampizarana • Fampianarana • Fanampiana\n\nMifampizara izay hainao. Mianara izay ilainao. Mifanampy amin’ny zavatra mahasoa.");
        tagline.setBackground(shape(Color.WHITE,20,Color.rgb(226,234,244)));root.addView(tagline);
        FirebaseUser signedIn=auth.getCurrentUser();
        root.addView(text("Tongasoa, "+safe(signedIn==null?"Mpampiasa":signedIn.getEmail())+" 👋"));
        TextView section=text("FIFANDRAISANA");section.setTextColor(BLUE);section.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(section);
        Button notificationButton=action("🔔 Fampandrenesana",v->notifications());
        root.addView(notificationButton);root.addView(action("💬 Hafatra / Chat",v->chatInbox()));
        if(signedIn!=null)db.collection("notifications").whereEqualTo("recipientId",signedIn.getUid()).whereEqualTo("read",false).get().addOnSuccessListener(q->{if(!q.isEmpty())notificationButton.setText("🔔 Fampandrenesana ("+q.size()+" vaovao)");});
        TextView learning=text("FAMPIANARANA");learning.setTextColor(BLUE);learning.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(learning);
        root.addView(action("📚 Hijery formation",v->catalogue()));root.addView(action("📖 Formation-ko",v->myCourses()));
        if("formateur".equals(currentRole)){
            TextView tools=text("FITAOVAN’NY FORMATEUR");tools.setTextColor(BLUE);tools.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(tools);
            root.addView(action("➕ Hampiditra formation",v->createCourse()));root.addView(action("💰 Vola sy fidiram-bola",v->formateurFinance()));
        }
        if("admin".equals(currentRole)){
            TextView tools=text("FITANTANANA ADMIN");tools.setTextColor(BLUE);tools.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(tools);
            root.addView(action("🛡 Dashboard Admin",v->adminDashboard()));root.addView(action("📚 Validation formations",v->adminCourses()));root.addView(action("💳 Gestion paiements",v->adminOrders()));root.addView(action("💸 Fangatahana retrait",v->adminPayouts()));root.addView(action("👥 Utilisateurs",v->adminUsers()));
        }
        TextView account=text("KAONTY");account.setTextColor(BLUE);account.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(account);
        root.addView(action("👤 Profil sy mombamomba",v->profile()));root.addView(action("Hivoaka",v->{auth.signOut();login();}));
    }
    // V13: fampandrenesana ao anatin'ny application.
    void sendNotification(String recipientId,String titleText,String message,String type){
        if(recipientId==null||recipientId.trim().isEmpty())return;
        Map<String,Object> n=new HashMap<>();n.put("recipientId",recipientId);n.put("title",titleText);n.put("message",message);n.put("type",type);n.put("read",false);n.put("createdAt",FieldValue.serverTimestamp());
        db.collection("notifications").add(n);
    }
    void notifications(){
        if(auth.getCurrentUser()==null){login();return;}
        base();root.addView(title("Fampandrenesana"));root.addView(text("Hita eto ny vaovao momba ny paiement, formation ary retrait-nao."));
        db.collection("notifications").whereEqualTo("recipientId",auth.getCurrentUser().getUid()).get().addOnSuccessListener(q->{
            if(q.isEmpty())root.addView(text("Mbola tsy misy fampandrenesana."));
            List<DocumentSnapshot> items=new ArrayList<>(q.getDocuments());
            Collections.sort(items,(a,b)->{Date da=a.getDate("createdAt"),dbb=b.getDate("createdAt");if(da==null)return 1;if(dbb==null)return -1;return dbb.compareTo(da);});
            for(DocumentSnapshot d:items){boolean read=Boolean.TRUE.equals(d.getBoolean("read"));TextView item=text((read?"":"● VAOVAO\n")+safe(d.getString("title"))+"\n"+safe(d.getString("message")));item.setBackgroundColor(read?Color.rgb(248,250,252):Color.rgb(232,242,255));root.addView(item);
                if(!read)root.addView(action("✓ Mariho fa voavaky",v->db.collection("notifications").document(d.getId()).update("read",true).addOnSuccessListener(x->notifications()).addOnFailureListener(e->toast("Tsy afaka nanavao ny fampandrenesana."))));
            }
        }).addOnFailureListener(e->toast("Tsy afaka naka fampandrenesana. Hamarino ny Firestore Rules."));
        root.addView(action("← Hiverina",v->home()));
    }
    void catalogue(){base();root.addView(title("Catalogue"));root.addView(text("Formation efa neken'ny Admin ihany no aseho eto."));db.collection("courses").whereEqualTo("status","approved").get().addOnSuccessListener(q->{if(q.isEmpty())root.addView(text("Mbola tsy misy formation voamarina."));for(DocumentSnapshot d:q.getDocuments()){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(14,14,14,14);card.setBackgroundColor(LIGHT);card.addView(text("📘 "+safe(d.getString("title"))));card.addView(text("Formateur: "+safe(d.getString("formateurName"))+"\nVidiny: "+money(d.getLong("price"))));card.addView(action("Hijery formation",v->courseDetail(d)));root.addView(card);}}).addOnFailureListener(e->toast("Tsy afaka naka catalogue."));root.addView(action("← Hiverina",v->home()));}
    void courseDetail(DocumentSnapshot d){base();root.addView(title(safe(d.getString("title"))));root.addView(text(safe(d.getString("description"))+"\n\nVidiny: "+money(d.getLong("price"))));String video=d.getString("videoUrl"),pdf=d.getString("pdfUrl");if(video!=null&&!video.isEmpty())root.addView(action("🎥 Hijery vidéo",v->openUrl(video)));if(pdf!=null&&!pdf.isEmpty())root.addView(action("📄 Hamaky PDF",v->openUrl(pdf)));root.addView(action("💬 Hiresaka amin’ny Formateur",v->startCourseChat(d)));root.addView(action("📝 Quiz sy fandrosoana",v->quizHub(d)));root.addView(action("💳 Hividy formation",v->paymentRequest(d)));root.addView(action("⭐ Naoty sy hevitra",v->reviews(d)));root.addView(action("← Hiverina",v->catalogue()));}
    void paymentRequest(DocumentSnapshot d){base();root.addView(title("Fividianana"));root.addView(text("Formation: "+safe(d.getString("title"))+"\nVidiny: "+money(d.getLong("price"))+"\n\nMVola: 034 88 989 84\nAirtel Money: 033 14 100 74\nAnarana: HERIMAMONJY HARITIANA FANAMBINANTSOA FIDERANA"));Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"MVola","Airtel Money"}));root.addView(sp);EditText ref=input("Référence transaction",false);root.addView(ref);Button send=btn("Handefa fangatahana");root.addView(send);
        send.setOnClickListener(v->{if(ref.getText().toString().trim().isEmpty()){toast("Ampidiro ny référence transaction.");return;}Map<String,Object> o=new HashMap<>();o.put("userId",auth.getCurrentUser().getUid());o.put("courseId",d.getId());o.put("courseTitle",d.getString("title"));o.put("formateurId",d.getString("formateurId"));o.put("formateurName",d.getString("formateurName"));o.put("amount",d.getLong("price"));o.put("method",sp.getSelectedItem().toString());o.put("receiverNumber",sp.getSelectedItemPosition()==0?"0348898984":"0331410074");o.put("receiver","HERIMAMONJY HARITIANA FANAMBINANTSOA FIDERANA");o.put("transactionRef",ref.getText().toString().trim());o.put("status","pending");o.put("commissionRate",25);o.put("formateurRate",75);o.put("createdAt",FieldValue.serverTimestamp());send.setEnabled(false);db.collection("orders").add(o).addOnSuccessListener(x->{toast("Voaray. Miandry validation Admin.");home();}).addOnFailureListener(e->{send.setEnabled(true);toast("Tsy nety ny fangatahana.");});});}
    void createCourse(){base();root.addView(title("Hampiditra formation"));EditText ct=input("Lohateny",false),desc=input("Description",false),price=input("Vidiny (Ar)",false);price.setInputType(InputType.TYPE_CLASS_NUMBER);root.addView(ct);root.addView(desc);root.addView(price);Button video=btn("🎥 Misafidy vidéo"),pdf=btn("📄 Misafidy PDF");root.addView(video);root.addView(pdf);TextView chosen=text("Vidéo: tsy voafidy\nPDF: tsy voafidy");root.addView(chosen);Button send=btn("Handefa formation hojerena");root.addView(send);root.addView(action("← Hiverina",v->home()));
        video.setOnClickListener(v->pickFile("video/*",101));pdf.setOnClickListener(v->pickFile("application/pdf",102));
        send.setOnClickListener(v->{String t=ct.getText().toString().trim(),p=price.getText().toString().trim();if(t.isEmpty()||p.isEmpty()){toast("Fenoy ny lohateny sy vidiny.");return;}long amount;try{amount=Long.parseLong(p);}catch(Exception e){toast("Vidiny tsy marina.");return;}if(amount<=0){toast("Vidiny tsy maintsy mihoatra ny 0.");return;}if(selectedVideo==null&&selectedPdf==null){toast("Misafidiana vidéo na PDF.");return;}send.setEnabled(false);uploadCourseFiles(t,desc.getText().toString().trim(),amount,send);});}
    void uploadCourseFiles(String title,String desc,long price,Button send){Map<String,String> urls=new HashMap<>();if(selectedVideo!=null)uploadOne(selectedVideo,"video",title,desc,price,urls,send);else if(selectedPdf!=null)uploadOne(selectedPdf,"pdf",title,desc,price,urls,send);}
    void uploadOne(Uri uri,String kind,String title,String desc,long price,Map<String,String> urls,Button send){String ext=kind.equals("video")?"mp4":"pdf";String path="courses/"+auth.getCurrentUser().getUid()+"/"+UUID.randomUUID()+"."+ext;StorageReference ref=storage.getReference().child(path);ref.putFile(uri).addOnProgressListener(t->{long total=t.getTotalByteCount();send.setText("⏳ Upload "+kind+" "+(total>0?(100*t.getBytesTransferred()/total):0)+"% ");}).addOnSuccessListener(t->ref.getDownloadUrl().addOnSuccessListener(u->{urls.put(kind,u.toString());if(kind.equals("video")&&selectedPdf!=null)uploadOne(selectedPdf,"pdf",title,desc,price,urls,send);else createCourseWithUrls(title,desc,price,urls,send);})).addOnFailureListener(e->{send.setEnabled(true);send.setText("Handefa formation hojerena");toast("Tsy nety ny upload "+kind+".");});}
    void createCourseWithUrls(String title,String desc,long price,Map<String,String> urls,Button send){Map<String,Object> c=new HashMap<>();c.put("title",title);c.put("description",desc);c.put("price",price);c.put("formateurId",auth.getCurrentUser().getUid());c.put("status","pending");c.put("formateurName",auth.getCurrentUser().getEmail());if(urls.get("video")!=null)c.put("videoUrl",urls.get("video"));if(urls.get("pdf")!=null)c.put("pdfUrl",urls.get("pdf"));c.put("createdAt",FieldValue.serverTimestamp());db.collection("courses").add(c).addOnSuccessListener(doc->{toast("Formation nalefa. Miandry validation Admin.");selectedVideo=null;selectedPdf=null;home();}).addOnFailureListener(e->{send.setEnabled(true);send.setText("Handefa formation hojerena");toast("Tsy nety ny tahiry.");});}
    void pickFile(String type,int code){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType(type);i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,code);}
    @Override protected void onActivityResult(int request,int result,Intent d){super.onActivityResult(request,result,d);if(result==RESULT_OK&&d!=null&&d.getData()!=null){try{getContentResolver().takePersistableUriPermission(d.getData(),Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}if(request==101)selectedVideo=d.getData();else if(request==102)selectedPdf=d.getData();toast(request==101?"Vidéo voafidy.":"PDF voafidy.");}}
    void openUrl(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){toast("Tsy misy application afaka manokatra ity fichier ity.");}}
    void adminCourses(){base();root.addView(title("Admin – Validation formations"));db.collection("courses").whereEqualTo("status","pending").get().addOnSuccessListener(q->{if(q.isEmpty())root.addView(text("Tsy misy formation miandry validation."));for(DocumentSnapshot d:q.getDocuments()){root.addView(text("📘 "+safe(d.getString("title"))+"\nFormateur: "+safe(d.getString("formateurName"))+"\nVidiny: "+money(d.getLong("price"))));Button ok=btn("✓ Manaiky"),no=btn("✕ Mandà");root.addView(ok);root.addView(no);ok.setOnClickListener(v->updateCourse(d.getId(),"approved"));no.setOnClickListener(v->updateCourse(d.getId(),"rejected"));}}).addOnFailureListener(e->toast("Tsy afaka naka demandes."));root.addView(action("← Hiverina",v->home()));}
    void adminDashboard(){
        if(!"admin".equals(currentRole)){toast("Admin ihany no mahazo miditra.");home();return;}
        base();root.addView(title("Dashboard Admin"));root.addView(text("Topimaso momba ny MIFANAMPY"));
        TextView stats=text("⏳ Maka statistika...");root.addView(stats);
        final long[] counts=new long[4]; final int[] pending={0};
        db.collection("users").get().addOnSuccessListener(u->{counts[0]=u.size();
            db.collection("courses").get().addOnSuccessListener(c->{counts[1]=c.size();
                for(DocumentSnapshot d:c.getDocuments())if("pending".equals(d.getString("status")))pending[0]++;
                db.collection("orders").get().addOnSuccessListener(o->{counts[2]=o.size();long paid=0;int waiting=0;for(DocumentSnapshot d:o.getDocuments()){if("approved".equals(d.getString("status"))){Long a=d.getLong("amount");if(a!=null)paid+=a;}if("pending".equals(d.getString("status")))waiting++;}
                    stats.setText("👥 Mpampiasa: "+counts[0]+"\n📚 Formations: "+counts[1]+" (miandry: "+pending[0]+")\n💳 Paiements: "+counts[2]+" (miandry: "+waiting+")\n💰 Vola voamarina: "+money(paid)+"\n\nFizarana tombanana: 25% MIFANAMPY / 75% Formateur");
                }).addOnFailureListener(e->stats.setText("Tsy afaka naka statistika paiement."));
            }).addOnFailureListener(e->stats.setText("Tsy afaka naka formations."));
        }).addOnFailureListener(e->stats.setText("Tsy afaka naka utilisateurs."));
        root.addView(action("💳 Hijery paiements",v->adminOrders()));root.addView(action("💸 Fangatahana retrait",v->adminPayouts()));root.addView(action("📚 Hijery formations",v->adminCourses()));root.addView(action("👥 Hijery utilisateurs",v->adminUsers()));root.addView(action("← Hiverina",v->home()));
    }
    void adminUsers(){
        if(!"admin".equals(currentRole)){toast("Admin ihany no mahazo miditra.");home();return;}
        base();root.addView(title("Gestion utilisateurs"));
        db.collection("users").get().addOnSuccessListener(q->{if(q.isEmpty())root.addView(text("Mbola tsy misy utilisateur."));for(DocumentSnapshot d:q.getDocuments()){
            String role=safe(d.getString("role"));root.addView(text("👤 "+safe(d.getString("name"))+"\n"+safe(d.getString("email"))+"\nTéléphone: "+safe(d.getString("phone"))+"\nRôle: "+role));
        }}).addOnFailureListener(e->toast("Tsy afaka naka utilisateurs. Jereo ny Firestore Rules."));
        root.addView(action("← Hiverina",v->adminDashboard()));
    }
    void adminOrders(){
        if(!"admin".equals(currentRole)){toast("Admin ihany no mahazo miditra.");home();return;}
        base();root.addView(title("Gestion paiements"));
        db.collection("orders").whereEqualTo("status","pending").get().addOnSuccessListener(q->{if(q.isEmpty())root.addView(text("Tsy misy paiement miandry validation."));for(DocumentSnapshot d:q.getDocuments()){
            Long amount=d.getLong("amount");String method=safe(d.getString("method"));
            root.addView(text("💳 "+safe(d.getString("courseTitle"))+"\nMontant: "+money(amount)+"\nMode: "+method+"\nRéférence: "+safe(d.getString("transactionRef"))+"\nUser: "+safe(d.getString("userId"))));
            root.addView(action("✓ Manamarina paiement",v->approveOrder(d)));root.addView(action("✕ Mandà paiement",v->rejectOrder(d.getId())));
        }}).addOnFailureListener(e->toast("Tsy afaka naka paiements."));
        root.addView(action("← Hiverina",v->adminDashboard()));
    }
    void approveOrder(DocumentSnapshot order){
        String uid=order.getString("userId"),cid=order.getString("courseId");if(uid==null||cid==null){toast("Tsy feno ny mombamomba ny commande.");return;}
        Long amount=order.getLong("amount");if(amount==null)amount=0L;long commission=Math.round(amount*0.25),formateur=Math.max(0,amount-commission);
        Map<String,Object> access=new HashMap<>();access.put("userId",uid);access.put("courseId",cid);access.put("courseTitle",order.getString("courseTitle"));access.put("status","active");access.put("createdAt",FieldValue.serverTimestamp());
        Map<String,Object> update=new HashMap<>();update.put("status","approved");update.put("commissionRate",25);update.put("formateurRate",75);update.put("commissionAmount",commission);update.put("formateurAmount",formateur);update.put("reviewedBy",auth.getCurrentUser().getUid());update.put("reviewedAt",FieldValue.serverTimestamp());
        WriteBatch batch=db.batch();batch.update(db.collection("orders").document(order.getId()),update);batch.set(db.collection("courseAccess").document(uid+"_"+cid),access);
        batch.commit().addOnSuccessListener(x->{sendNotification(uid,"Paiement voamarina","Voamarina ny fandoavanao ny formation: "+safe(order.getString("courseTitle"))+". Afaka miditra amin'izany ianao izao.","payment_approved");toast("Paiement voamarina. Fidirana amin'ny formation nosokafana.");adminOrders();}).addOnFailureListener(e->toast("Tsy nety ny validation: "+e.getMessage()));
    }
    void rejectOrder(String id){db.collection("orders").document(id).get().addOnSuccessListener(order->{String uid=order.getString("userId");Map<String,Object> m=new HashMap<>();m.put("status","rejected");m.put("reviewedBy",auth.getCurrentUser().getUid());m.put("reviewedAt",FieldValue.serverTimestamp());db.collection("orders").document(id).update(m).addOnSuccessListener(x->{sendNotification(uid,"Paiement nolavina","Tsy nekena ny fangatahanao momba ny "+safe(order.getString("courseTitle"))+". Mifandraisa amin'ny Admin raha mila fanazavana.","payment_rejected");toast("Paiement nolavina.");adminOrders();}).addOnFailureListener(e->toast("Tsy nety ny fandavana."));}).addOnFailureListener(e->toast("Tsy hita ilay paiement."));}
    // V12: fidiram-bola sy fangatahana retrait ho an'ny formateur.
    void formateurFinance(){
        if(!"formateur".equals(currentRole)){toast("Formateur ihany no mahazo miditra.");home();return;}
        base();root.addView(title("Vola sy fidiram-bola"));TextView summary=text("⏳ Maka ny tatitra...");root.addView(summary);
        db.collection("orders").whereEqualTo("formateurId",auth.getCurrentUser().getUid()).whereEqualTo("status","approved").get().addOnSuccessListener(q->{long gross=0,earned=0,commission=0;for(DocumentSnapshot d:q.getDocuments()){Long a=d.getLong("amount"),f=d.getLong("formateurAmount"),c=d.getLong("commissionAmount");if(a!=null)gross+=a;if(f!=null)earned+=f;if(c!=null)commission+=c;}
            final long totalEarned=earned;db.collection("payoutRequests").whereEqualTo("formateurId",auth.getCurrentUser().getUid()).get().addOnSuccessListener(p->{long reserved=0,paid=0;for(DocumentSnapshot d:p.getDocuments()){Long a=d.getLong("amount");if(a!=null){if("pending".equals(d.getString("status")))reserved+=a;if("paid".equals(d.getString("status")))paid+=a;}}
                long available=Math.max(0,totalEarned-reserved-paid);summary.setText("Vola nivarotana: "+money(gross)+"\nAnjaranao (75%): "+money(totalEarned)+"\nAnjaran'ny MIFANAMPY (25%): "+money(commission)+"\nEfa voaloa: "+money(paid)+"\nMiandry retrait: "+money(reserved)+"\n\nAzo angatahina: "+money(available));
                Button request=btn("💸 Hangataka retrait");root.addView(request);request.setOnClickListener(v->requestPayout(available));
            }).addOnFailureListener(e->summary.setText("Tsy afaka naka ny fangatahana retrait."));
        }).addOnFailureListener(e->summary.setText("Tsy mbola misy fidiram-bola voamarina, na tsy hita ny tatitra."));
        root.addView(action("📄 Tantaran'ny retrait",v->myPayouts()));root.addView(action("← Hiverina",v->home()));
    }
    void requestPayout(long available){
        if(available<=0){toast("Tsy mbola misy vola azo angatahina.");return;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);EditText amount=input("Vola alaina (Ar)",false);amount.setInputType(InputType.TYPE_CLASS_NUMBER);EditText number=input("Laharana Mobile Money-nao",false);Spinner method=new Spinner(this);method.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"MVola","Airtel Money"}));box.addView(text("Azo angatahina hatramin'ny "+money(available)));box.addView(amount);box.addView(method);box.addView(number);
        new AlertDialog.Builder(this).setTitle("Fangatahana retrait").setView(box).setNegativeButton("Hanafoana",null).setPositiveButton("Handefa",(di,w)->{long a;try{a=Long.parseLong(amount.getText().toString().trim());}catch(Exception ex){toast("Ampidiro ny vola marina.");return;}String n=number.getText().toString().trim();if(a<=0||a>available||n.length()<9){toast("Hamarino ny vola sy ny laharana.");return;}Map<String,Object> m=new HashMap<>();m.put("formateurId",auth.getCurrentUser().getUid());m.put("formateurEmail",auth.getCurrentUser().getEmail());m.put("amount",a);m.put("method",method.getSelectedItem().toString());m.put("phone",n);m.put("status","pending");m.put("createdAt",FieldValue.serverTimestamp());db.collection("payoutRequests").add(m).addOnSuccessListener(x->{toast("Voaray ny fangatahana retrait. Miandry Admin.");formateurFinance();}).addOnFailureListener(e->toast("Tsy nety ny fangatahana: "+e.getMessage()));}).show();
    }
    void myPayouts(){base();root.addView(title("Tantaran'ny retrait"));db.collection("payoutRequests").whereEqualTo("formateurId",auth.getCurrentUser().getUid()).get().addOnSuccessListener(q->{if(q.isEmpty())root.addView(text("Mbola tsy nisy fangatahana."));for(DocumentSnapshot d:q.getDocuments())root.addView(text("💸 "+money(d.getLong("amount"))+"\n"+safe(d.getString("method"))+" – "+safe(d.getString("phone"))+"\nSata: "+safe(d.getString("status"))));}).addOnFailureListener(e->toast("Tsy afaka naka ny tantara."));root.addView(action("← Hiverina",v->formateurFinance()));}
    void adminPayouts(){
        if(!"admin".equals(currentRole)){toast("Admin ihany no mahazo miditra.");home();return;}
        base();root.addView(title("Fangatahana retrait"));db.collection("payoutRequests").whereEqualTo("status","pending").get().addOnSuccessListener(q->{if(q.isEmpty())root.addView(text("Tsy misy fangatahana miandry."));for(DocumentSnapshot d:q.getDocuments()){root.addView(text("💸 "+money(d.getLong("amount"))+"\nFormateur: "+safe(d.getString("formateurEmail"))+"\nFomba: "+safe(d.getString("method"))+"\nLaharana: "+safe(d.getString("phone"))));root.addView(action("✓ Voaloa / Hamita",v->markPayout(d.getId(),"paid")));root.addView(action("✕ Mandà",v->markPayout(d.getId(),"rejected")));}}).addOnFailureListener(e->toast("Tsy afaka naka fangatahana retrait."));root.addView(action("← Hiverina",v->home()));
    }
    void markPayout(String id,String status){db.collection("payoutRequests").document(id).get().addOnSuccessListener(request->{String uid=request.getString("formateurId");Map<String,Object> m=new HashMap<>();m.put("status",status);m.put("reviewedBy",auth.getCurrentUser().getUid());m.put("reviewedAt",FieldValue.serverTimestamp());db.collection("payoutRequests").document(id).update(m).addOnSuccessListener(x->{sendNotification(uid,status.equals("paid")?"Retrait voaloa":"Retrait nolavina",status.equals("paid")?"Vita ny fandoavana ny retrait-nao. Jereo ny kaontinao Mobile Money.":"Nolavina ny fangatahana retrait-nao. Mifandraisa amin'ny Admin raha mila fanazavana.","payout_"+status);toast(status.equals("paid")?"Voamarika fa voaloa ny retrait.":"Nolavina ny fangatahana.");adminPayouts();}).addOnFailureListener(e->toast("Tsy nety ny fanavaozana."));}).addOnFailureListener(e->toast("Tsy hita ny fangatahana retrait."));}
    void updateCourse(String id,String status){db.collection("courses").document(id).get().addOnSuccessListener(course->{String fid=course.getString("formateurId"),courseTitle=course.getString("title");Map<String,Object> m=new HashMap<>();m.put("status",status);m.put("reviewedAt",FieldValue.serverTimestamp());m.put("reviewedBy",auth.getCurrentUser().getUid());db.collection("courses").document(id).update(m).addOnSuccessListener(v->{sendNotification(fid,status.equals("approved")?"Formation nekena":"Formation nolavina",status.equals("approved")?"Neken'ny Admin ny formation-nao: "+safe(courseTitle)+". Hita ao amin'ny catalogue izao.":"Tsy neken'ny Admin ny formation-nao: "+safe(courseTitle)+". Azonao jerena sy ahitsy ny antsipiriany.","course_"+status);toast(status.equals("approved")?"Formation nekena.":"Formation nolavina.");adminCourses();}).addOnFailureListener(e->toast("Tsy nety ny fanovana."));}).addOnFailureListener(e->toast("Tsy hita ilay formation."));}
    void myCourses(){base();root.addView(title("Formation-ko"));db.collection("courseAccess").whereEqualTo("userId",auth.getCurrentUser().getUid()).whereEqualTo("status","active").get().addOnSuccessListener(q->{if(q.isEmpty())root.addView(text("Mbola tsy misy formation azonao idirana."));for(DocumentSnapshot d:q.getDocuments()){root.addView(action("📖 "+safe(d.getString("courseTitle")),v->loadCourseById(d.getString("courseId"))));}}).addOnFailureListener(e->toast("Tsy afaka naka formation-nao."));root.addView(action("← Hiverina",v->home()));}
    void loadCourseById(String id){if(id==null){toast("Formation tsy hita.");return;}db.collection("courses").document(id).get().addOnSuccessListener(d->{if(d.exists())courseDetail(d);else toast("Formation tsy hita intsony.");});}

    // V14: fifampiresahana mivantana eo amin'ny Mpianatra sy Formateur.
    void startCourseChat(DocumentSnapshot course){
        if(auth.getCurrentUser()==null){login();return;}
        String formateurId=course.getString("formateurId");
        if(formateurId==null||formateurId.trim().isEmpty()){toast("Tsy hita ny kaontin'ny Formateur.");return;}
        if(formateurId.equals(auth.getCurrentUser().getUid())){toast("Ianao no Formateur namorona ity formation ity.");return;}
        db.collection("users").document(auth.getCurrentUser().getUid()).get().addOnSuccessListener(me->{
            String myName=me.getString("name"); if(myName==null)myName=auth.getCurrentUser().getEmail();
            String otherName=course.getString("formateurName"); if(otherName==null)otherName="Formateur";
            openOrCreateChat(formateurId,otherName,course.getId(),course.getString("title"),myName);
        }).addOnFailureListener(e->toast("Tsy afaka naka ny mombamomba anao."));
    }
    void openOrCreateChat(String otherUid,String otherName,String courseId,String courseTitle,String myName){
        String me=auth.getCurrentUser().getUid();
        db.collection("chats").whereArrayContains("participantIds",me).get().addOnSuccessListener(q->{
            for(DocumentSnapshot d:q.getDocuments()){
                List<String> ids=(List<String>)d.get("participantIds");
                if(ids!=null&&ids.contains(otherUid)){openChat(d.getId(),otherName);return;}
            }
            Map<String,Object> names=new HashMap<>();names.put(me,myName);names.put(otherUid,otherName);
            Map<String,Object> data=new HashMap<>();data.put("participantIds",Arrays.asList(me,otherUid));data.put("participantNames",names);data.put("createdBy",me);data.put("courseId",courseId);data.put("courseTitle",courseTitle==null?"":courseTitle);data.put("lastMessage","Miresaka momba ny formation");data.put("lastSenderUid",me);data.put("createdAt",FieldValue.serverTimestamp());data.put("lastMessageAt",FieldValue.serverTimestamp());
            db.collection("chats").add(data).addOnSuccessListener(ref->openChat(ref.getId(),otherName)).addOnFailureListener(e->toast("Tsy afaka nanokatra chat: "+e.getMessage()));
        }).addOnFailureListener(e->toast("Tsy afaka naka ny lisitry ny chat."));
    }
    void chatInbox(){
        if(auth.getCurrentUser()==null){login();return;}
        base();root.addView(title("Hafatra / Chat"));root.addView(text("Resaho mivantana ny fanontaniana momba ny formation."));
        db.collection("chats").whereArrayContains("participantIds",auth.getCurrentUser().getUid()).get().addOnSuccessListener(q->{
            if(q.isEmpty())root.addView(text("Mbola tsy manana resaka ianao. Midira amin’ny formation iray dia tsindrio ‘Hiresaka amin’ny Formateur’."));
            List<DocumentSnapshot> chats=new ArrayList<>(q.getDocuments());
            Collections.sort(chats,(a,b)->{Date da=a.getDate("lastMessageAt"),dbb=b.getDate("lastMessageAt");if(da==null)return 1;if(dbb==null)return -1;return dbb.compareTo(da);});
            for(DocumentSnapshot d:chats){List<String> ids=(List<String>)d.get("participantIds");String other="Mpampiasa";Map<String,Object> names=(Map<String,Object>)d.get("participantNames");if(ids!=null&&names!=null)for(String id:ids)if(!id.equals(auth.getCurrentUser().getUid())&&names.get(id)!=null)other=String.valueOf(names.get(id));String course=d.getString("courseTitle");final String otherLabel=other;root.addView(action("💬 "+otherLabel+"\n"+(course==null?"":course)+"\n"+safe(d.getString("lastMessage")),v->openChat(d.getId(),otherLabel)));}
        }).addOnFailureListener(e->toast("Tsy afaka naka ny hafatra. Hamarino ny Firestore Rules."));
        root.addView(action("← Hiverina",v->home()));
    }
    void openChat(String chatId,String otherName){
        base();root.addView(title("Chat – "+otherName));TextView messages=text("Maka hafatra...");root.addView(messages);
        db.collection("chats").document(chatId).collection("messages").orderBy("createdAt",Query.Direction.ASCENDING).get().addOnSuccessListener(q->{
            messages.setText("");if(q.isEmpty())messages.setText("Mbola tsy misy hafatra. Atombohy ny resaka.");
            for(DocumentSnapshot d:q.getDocuments()){String sender=d.getString("senderUid");String label=auth.getCurrentUser().getUid().equals(sender)?"Ianao":"";String body=d.getString("text");messages.append((label.isEmpty()?"":"\n"+label+": ")+safe(body)+"\n────────────────────\n");}
        }).addOnFailureListener(e->messages.setText("Tsy afaka naka hafatra. Hamarino ny Firestore Rules."));
        EditText composer=input("Soraty eto ny hafatra...",false);root.addView(composer);Button send=btn("Alefa");root.addView(send);
        send.setOnClickListener(v->{String body=composer.getText().toString().trim();if(body.isEmpty())return;if(body.length()>2000){toast("Hafatra lava loatra (2 000 caractères farafahabetsany).");return;}String uid=auth.getCurrentUser().getUid();Map<String,Object> m=new HashMap<>();m.put("senderUid",uid);m.put("text",body);m.put("createdAt",FieldValue.serverTimestamp());db.collection("chats").document(chatId).collection("messages").add(m).addOnSuccessListener(ref->{Map<String,Object> update=new HashMap<>();update.put("lastMessage",body);update.put("lastSenderUid",uid);update.put("lastMessageAt",FieldValue.serverTimestamp());db.collection("chats").document(chatId).update(update).addOnSuccessListener(x->openChat(chatId,otherName)).addOnFailureListener(e->toast("Nalefa ny hafatra fa tsy voavaovao ny lisitra."));}).addOnFailureListener(e->toast("Tsy tafavoaka ny hafatra: "+e.getMessage()));});
        root.addView(action("← Hiverina amin’ny hafatra",v->chatInbox()));
    }

    // V15: quiz sy fanaraha-maso ny fandrosoan'ny mpianatra.
    void quizHub(DocumentSnapshot course){
        if(auth.getCurrentUser()==null){login();return;}
        String courseId=course.getId();
        base();root.addView(title("Quiz – "+safe(course.getString("title"))));
        root.addView(text("Valio ny fanontaniana ary araho eto ny vokatrao sy ny fandrosoanao."));
        String owner=course.getString("formateurId");
        boolean canManage="admin".equals(currentRole)||("formateur".equals(currentRole)&&auth.getCurrentUser().getUid().equals(owner));
        if(canManage)root.addView(action("➕ Hamorona quiz",v->createQuiz(course)));
        db.collection("quizzes").whereEqualTo("courseId",courseId).get().addOnSuccessListener(q->{
            if(q.isEmpty())root.addView(text("Mbola tsy misy quiz ho an'ity formation ity."));
            for(DocumentSnapshot quiz:q.getDocuments()){
                String label=safe(quiz.getString("title"));Long count=quiz.getLong("questionCount");
                root.addView(action("📝 "+label+"\nFanontaniana: "+(count==null?"1":count)+"\nHanomboka / Hijery",v->takeQuiz(course,quiz)));
            }
        }).addOnFailureListener(e->toast("Tsy afaka naka ny quiz. Hamarino ny Firestore Rules."));
        showProgress(courseId);
        root.addView(action("← Hiverina amin'ny formation",v->courseDetail(course)));
    }
    void createQuiz(DocumentSnapshot course){
        if(!"admin".equals(currentRole)&&!("formateur".equals(currentRole)&&auth.getCurrentUser().getUid().equals(course.getString("formateurId")))){toast("Formateur tompon'ity formation ity na Admin ihany no afaka mamorona quiz.");return;}
        base();root.addView(title("Mamorona quiz"));
        EditText quizTitle=input("Lohatenin'ny quiz",false),question=input("Fanontaniana",false),a=input("Safidy A",false),b=input("Safidy B",false),c=input("Safidy C",false),d=input("Safidy D",false);
        root.addView(quizTitle);root.addView(question);root.addView(text("Safidy valiny"));root.addView(a);root.addView(b);root.addView(c);root.addView(d);
        Spinner correct=new Spinner(this);correct.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"A no valiny marina","B no valiny marina","C no valiny marina","D no valiny marina"}));root.addView(correct);
        root.addView(text("Amin'ity V15 ity dia fanontaniana iray isaky ny quiz no amboarina. Azo ampiana quiz maromaro.") );
        Button save=btn("💾 Tehirizo ny quiz");root.addView(save);
        save.setOnClickListener(v->{String qt=quizTitle.getText().toString().trim(),qu=question.getText().toString().trim();String[] opts={a.getText().toString().trim(),b.getText().toString().trim(),c.getText().toString().trim(),d.getText().toString().trim()};if(qt.isEmpty()||qu.isEmpty()){toast("Fenoy ny lohateny sy ny fanontaniana.");return;}for(String op:opts)if(op.isEmpty()){toast("Fenoy avokoa ny safidy A, B, C ary D.");return;}
            Map<String,Object> m=new HashMap<>();m.put("courseId",course.getId());m.put("courseTitle",safe(course.getString("title")));m.put("formateurId",auth.getCurrentUser().getUid());m.put("title",qt);m.put("question",qu);m.put("options",Arrays.asList(opts));m.put("correctIndex",correct.getSelectedItemPosition());m.put("questionCount",1);m.put("createdAt",FieldValue.serverTimestamp());
            db.collection("quizzes").add(m).addOnSuccessListener(ref->{toast("Voatahiry ny quiz.");quizHub(course);}).addOnFailureListener(e->toast("Tsy voatahiry ny quiz: "+e.getMessage()));
        });
        root.addView(action("← Hiverina",v->quizHub(course)));
    }
    void takeQuiz(DocumentSnapshot course,DocumentSnapshot quiz){
        base();root.addView(title(safe(quiz.getString("title"))));root.addView(text(safe(quiz.getString("question"))));
        List<String> options=(List<String>)quiz.get("options");if(options==null||options.size()!=4){root.addView(text("Tsy feno ny safidy valiny."));return;}
        RadioGroup group=new RadioGroup(this);group.setOrientation(RadioGroup.VERTICAL);RadioButton[] radios=new RadioButton[4];for(int i=0;i<4;i++){radios[i]=new RadioButton(this);radios[i].setText((char)('A'+i)+". "+options.get(i));radios[i].setId(100+i);group.addView(radios[i]);}root.addView(group);
        Button submit=btn("Alefa ny valiny");root.addView(submit);
        submit.setOnClickListener(v->{int checked=group.getCheckedRadioButtonId();if(checked<100||checked>103){toast("Misafidiana valiny iray aloha.");return;}int chosen=checked-100;Long correct=quiz.getLong("correctIndex");if(correct==null){toast("Tsy hita ny valiny marina.");return;}int score=chosen==correct.intValue()?1:0;
            Map<String,Object> attempt=new HashMap<>();attempt.put("quizId",quiz.getId());attempt.put("quizTitle",safe(quiz.getString("title")));attempt.put("courseId",course.getId());attempt.put("courseTitle",safe(course.getString("title")));attempt.put("userId",auth.getCurrentUser().getUid());attempt.put("score",score);attempt.put("total",1);attempt.put("percentage",score*100);attempt.put("selectedIndex",chosen);attempt.put("createdAt",FieldValue.serverTimestamp());
            db.collection("quizAttempts").add(attempt).addOnSuccessListener(ref->{base();root.addView(title("Vokatry ny quiz"));root.addView(text(score==1?"🎉 Marina ny valinteninao!\nNaoty: 1/1 (100%)":"Mbola mila mamerina mianatra.\nNaoty: 0/1 (0%)"));root.addView(text("Tadidio: ny tanjon'ny quiz dia hanampy anao handrefy ny fahatakaranao ny lesona."));root.addView(action("Jereo ny fandrosoako",x->quizHub(course)));}).addOnFailureListener(e->toast("Tsy voatahiry ny valiny: "+e.getMessage()));
        });
        root.addView(action("← Hiverina",v->quizHub(course)));
    }
    void showProgress(String courseId){
        root.addView(title("Fandrosoako"));
        db.collection("quizAttempts").whereEqualTo("userId",auth.getCurrentUser().getUid()).get().addOnSuccessListener(q->{
            int attempts=0,sum=0;for(DocumentSnapshot d:q.getDocuments()){if(!courseId.equals(d.getString("courseId")))continue;attempts++;Long score=d.getLong("score");if(score!=null)sum+=score.intValue();}
            int percent=attempts==0?0:(int)Math.round(sum*100.0/attempts);
            root.addView(text("Isan'ny quiz natao: "+attempts+"\nValiny marina: "+sum+"\nTaha-pahombiazana: "+percent+"%"));
            ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(percent);root.addView(bar);
            if(attempts==0)root.addView(text("Mbola tsy nanao quiz ianao. Rehefa mamaly quiz dia hiseho eto ny fandrosoanao."));
        }).addOnFailureListener(e->toast("Tsy afaka naka ny fandrosoana."));
    }

    // V16: naoty sy hevitra momba ny formation.
    void reviews(DocumentSnapshot course){
        base();root.addView(title("⭐ Naoty sy hevitra"));root.addView(text("Formation: "+safe(course.getString("title"))));
        db.collection("reviews").whereEqualTo("courseId",course.getId()).get().addOnSuccessListener(q->{
            double sum=0;int count=0;for(DocumentSnapshot r:q.getDocuments()){Long rating=r.getLong("rating");if(rating!=null){sum+=rating;count++;}}
            root.addView(text(count==0?"Mbola tsy misy naoty.":String.format(Locale.US,"Naoty salan'isa: %.1f/5 ⭐ (%d hevitra)",sum/count,count)));
            List<DocumentSnapshot> list=new ArrayList<>(q.getDocuments());Collections.sort(list,(a,b)->{Date da=a.getDate("createdAt"),dbb=b.getDate("createdAt");if(da==null)return 1;if(dbb==null)return -1;return dbb.compareTo(da);});
            for(DocumentSnapshot r:list){Long rating=r.getLong("rating");root.addView(text("⭐ "+(rating==null?"-":rating)+"/5 — "+safe(r.getString("userName"))+"\n"+safe(r.getString("comment"))));}
        }).addOnFailureListener(e->toast("Tsy afaka naka ny hevitra. Hamarino ny Firestore Rules."));
        root.addView(title("Hanome naoty"));Spinner stars=new Spinner(this);stars.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"5 ⭐ — Tena tsara","4 ⭐ — Tsara","3 ⭐ — Antonony","2 ⭐ — Tsy dia tsara","1 ⭐ — Tsy tsara"}));root.addView(stars);
        EditText comment=input("Soraty eto ny hevitrao (tsy voatery)",false);comment.setMinLines(3);comment.setGravity(Gravity.TOP);root.addView(comment);Button send=btn("Handefa naoty sy hevitra");root.addView(send);
        send.setOnClickListener(v->{FirebaseUser user=auth.getCurrentUser();if(user==null){login();return;}String uid=user.getUid(),cid=course.getId(),body=comment.getText().toString().trim();if(body.length()>500){toast("Tsy tokony hihoatra ny 500 caractères ny hevitra.");return;}int rating=5-stars.getSelectedItemPosition();Map<String,Object> data=new HashMap<>();data.put("courseId",cid);data.put("courseTitle",safe(course.getString("title")));data.put("userId",uid);data.put("userName",safe(user.getDisplayName()).isEmpty()?safe(user.getEmail()):user.getDisplayName());data.put("rating",rating);data.put("comment",body);data.put("createdAt",FieldValue.serverTimestamp());data.put("updatedAt",FieldValue.serverTimestamp());
            send.setEnabled(false);db.collection("reviews").document(cid+"_"+uid).set(data,SetOptions.merge()).addOnSuccessListener(x->{toast("Voaray ny naoty sy hevitrao. Misaotra!");reviews(course);}).addOnFailureListener(e->{send.setEnabled(true);toast("Tsy nety ny fandefasana. Hamarino ny Firestore Rules.");});});
        root.addView(action("← Hiverina amin'ny formation",v->courseDetail(course)));
    }

    void profile(){
        FirebaseUser user=auth.getCurrentUser();if(user==null){login();return;}
        base();root.addView(title("Mombamomba ahy"));root.addView(text("Havaozy eto ny anaranao sy ny laharana finday ampiasainao."));
        EditText name=input("Anarana feno",false),phone=input("Laharana finday",false);
        TextView email=text("Email: "+safe(user.getEmail()));email.setBackground(shape(Color.WHITE,14,Color.rgb(226,234,244)));root.addView(email);
        TextView role=text("Karazana kaonty: "+("admin".equals(currentRole)?"Admin":"formateur".equals(currentRole)?"Formateur":"Mpianatra / Mpampiasa"));root.addView(role);
        root.addView(name);root.addView(phone);
        Button save=action("💾 Tehirizo ny fanovana",v->{String n=name.getText().toString().trim(),p=phone.getText().toString().trim();if(n.length()<2){toast("Ampidiro ny anaranao feno.");return;}if(!p.isEmpty()&&p.replaceAll("[^0-9]","").length()<9){toast("Hamarino ny laharana finday.");return;}Map<String,Object> changes=new HashMap<>();changes.put("name",n);changes.put("phone",p);db.collection("users").document(user.getUid()).update(changes).addOnSuccessListener(x->{toast("Voatahiry ny mombamomba anao.");profile();}).addOnFailureListener(e->toast("Tsy voatahiry. Hamarino ny Firestore Rules."));});
        root.addView(save);
        db.collection("users").document(user.getUid()).get().addOnSuccessListener(d->{if(d.exists()){name.setText(safe(d.getString("name")));phone.setText(safe(d.getString("phone")));}}).addOnFailureListener(e->toast("Tsy afaka naka ny mombamomba anao."));
        root.addView(action("🔑 Hanova mot de passe",v->{EditText emailInput=input("Email",false);emailInput.setText(safe(user.getEmail()));new AlertDialog.Builder(this).setTitle("Famerenana mot de passe").setMessage("Handefa rohy fanovana mot de passe amin'ity email ity ve?").setView(emailInput).setNegativeButton("Hanafoana",null).setPositiveButton("Handefa",(dialog,which)->{String em=emailInput.getText().toString().trim();if(em.isEmpty()){toast("Ampidiro ny email.");return;}auth.sendPasswordResetEmail(em).addOnSuccessListener(x->toast("Nalefa ny toromarika raha marina ilay email.")).addOnFailureListener(e->toast("Tsy afaka nandefa email. Hamarino ny adiresy."));}).show();}));
        root.addView(action("← Hiverina",v->home()));
    }
    String safe(String s){return s==null?"":s;}String money(Long n){return n==null?"0 Ar":String.format(Locale.US,"%,d Ar",n).replace(',',' ');}void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
